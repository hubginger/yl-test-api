# coding=utf-8
"""

"""

# @Time    :  2024-01-03 11:04:04
# @Author  :  jiangtong
# @Email   :  gingerqgyy@outlook.com
# @Project :  yl_test_api
# @File    :  demo_conf_read

from common import do_conf

print(do_conf.read_all('request'))
