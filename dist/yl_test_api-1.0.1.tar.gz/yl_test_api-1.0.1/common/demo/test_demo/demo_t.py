# coding=utf-8
"""

"""

# @Time    :  2024-01-03 18:26:33
# @Author  :  jiangtong
# @Email   :  gingerqgyy@outlook.com
# @Project :  yl_test_api
# @File    :  demo_t


import time

print(time.time())
