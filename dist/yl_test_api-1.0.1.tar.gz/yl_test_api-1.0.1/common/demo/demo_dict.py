# coding=utf-8
"""

"""

# @Time    :  2024-01-04 10:43:34
# @Author  :  jiangtong
# @Email   :  gingerqgyy@outlook.com
# @Project :  yl_test_api
# @File    :  demo_dict
response = {"code": "OK", "result": {"user_info": {"name": "Admin"}}}
