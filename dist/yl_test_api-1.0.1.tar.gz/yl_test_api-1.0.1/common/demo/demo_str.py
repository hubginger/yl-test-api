# coding=utf-8
"""

"""

# @Time    :  2024-01-01 23:44:59
# @Author  :  jiangtong
# @Email   :  jiangtong@yljt.cn
# @Project :  yljk_test_api
# @File    :  demo_str

a = 'login'
b = 'login001'

print(b.strip(a))
