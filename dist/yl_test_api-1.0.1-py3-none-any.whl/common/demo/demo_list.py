# coding=utf-8
"""

"""

# @Time    :  2023-12-31 01:30:41
# @Author  :  jiangtong
# @Email   :  jiangtong@yljt.cn
# @Project :  yljk_test_api
# @File    :  demo_list

li = [1, 2, 3, 4, 5]
print(li[:-1])
