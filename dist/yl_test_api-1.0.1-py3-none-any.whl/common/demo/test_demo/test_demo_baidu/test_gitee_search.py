# coding=utf-8
"""

"""


# @Time    :  2024-01-03 09:51:12
# @Author  :  jiangtong
# @Email   :  gingerqgyy@outlook.com
# @Project :  yl_test_api
# @File    :  test_gitee_search

class TestGitee:

    def test_function(self):
        print()
        pass

    def test_login(self):
        pass

    def test_main_page(self):
        pass

    def test_bbbbb(self):
        pass

    def test_action(self):
        pass
