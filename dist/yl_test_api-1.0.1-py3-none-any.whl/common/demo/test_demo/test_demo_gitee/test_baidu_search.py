# coding=utf-8
"""

"""


# @Time    :  2024-01-03 09:50:46
# @Author  :  jiangtong
# @Email   :  gingerqgyy@outlook.com
# @Project :  yl_test_api
# @File    :  test_baidu_search


class TestBaidu:

    def test_search(self):
        pass

    def test_action(self):
        pass

    def test_xxx(self):
        pass
